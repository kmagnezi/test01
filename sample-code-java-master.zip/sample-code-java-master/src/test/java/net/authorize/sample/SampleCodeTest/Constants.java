package net.authorize.sample.SampleCodeTest;

public final class Constants {
	public static final String API_LOGIN_ID = "5KP3u95bQpv";
	public static final String TRANSACTION_KEY = "346HZ32z3fP4hTG2";
	public static final String TRANSACTION_ID = "123456";
	public static final String PAYER_ID = "6ZSCSYG33VP8Q";
	public static final String CONFIG_FILE = "./src/test/java/net/authorize/sample/SampleCodeTest/SampleCodeList.txt";
}
